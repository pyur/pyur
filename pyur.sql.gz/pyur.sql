-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 10, 2016 at 06:04 AM
-- Server version: 5.5.37
-- PHP Version: 5.4.36

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pyur`
--

-- --------------------------------------------------------

--
-- Table structure for table `auto`
--

CREATE TABLE IF NOT EXISTS `auto` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `val` mediumint(8) unsigned NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `call`
--

CREATE TABLE IF NOT EXISTS `call` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imei` tinyint(3) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL,
  `dt` datetime NOT NULL,
  `phone` varbinary(10) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `duration` smallint(5) unsigned NOT NULL,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `elec`
--

CREATE TABLE IF NOT EXISTS `elec` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `val` mediumint(8) unsigned NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE IF NOT EXISTS `expense` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `store` tinyint(3) unsigned NOT NULL,
  `desc` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_doc`
--

CREATE TABLE IF NOT EXISTS `expense_doc` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `p` mediumint(8) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_item`
--

CREATE TABLE IF NOT EXISTS `expense_item` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `p` mediumint(8) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `desc` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `host`
--

CREATE TABLE IF NOT EXISTS `host` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ip` int(10) unsigned NOT NULL,
  `ipe` int(10) unsigned NOT NULL,
  `dateb` date NOT NULL,
  `datee` date NOT NULL,
  `metric` tinyint(3) unsigned NOT NULL,
  `desc` varchar(256) NOT NULL,
  `stat` tinyint(3) unsigned NOT NULL,
  `color` varchar(32) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE IF NOT EXISTS `income` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `money` int(10) unsigned NOT NULL,
  `person` tinyint(3) unsigned NOT NULL,
  `desc` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lenta`
--

CREATE TABLE IF NOT EXISTS `lenta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `link_type` tinyint(3) unsigned NOT NULL,
  `link_date` date NOT NULL,
  `link` varbinary(64) NOT NULL,
  `desc` varbinary(128) NOT NULL,
  `descf` varbinary(32768) NOT NULL,
  `stat` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lenta_img`
--

CREATE TABLE IF NOT EXISTS `lenta_img` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lenta` int(10) unsigned NOT NULL,
  `w` smallint(5) unsigned NOT NULL DEFAULT '0',
  `h` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lenta_pref`
--

CREATE TABLE IF NOT EXISTS `lenta_pref` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `lenta` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `server` tinyint(3) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `datetime` datetime NOT NULL,
  `methodn` tinyint(3) unsigned NOT NULL,
  `uri` varbinary(4096) NOT NULL,
  `httpvn` tinyint(3) unsigned NOT NULL,
  `resultn` tinyint(3) unsigned NOT NULL,
  `bytes` int(10) unsigned NOT NULL,
  `referer` varbinary(4096) NOT NULL,
  `uan` mediumint(8) unsigned NOT NULL,
  `userx` smallint(5) unsigned NOT NULL,
  `ipf` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server` (`server`),
  KEY `datetime` (`datetime`),
  KEY `uan` (`uan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `log_check`
--

CREATE TABLE IF NOT EXISTS `log_check` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file` varbinary(512) NOT NULL,
  `last_row` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `otchestvo` varchar(32) NOT NULL,
  `surnamef` varchar(32) NOT NULL,
  `nickname` varchar(32) NOT NULL,
  `birthdate` date NOT NULL,
  `deathdate` date NOT NULL,
  `vk` varbinary(32) NOT NULL,
  `ok` varbinary(32) NOT NULL,
  `fb` varbinary(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_addr`
--

CREATE TABLE IF NOT EXISTS `people_addr` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pid` mediumint(8) unsigned NOT NULL,
  `addr` varchar(128) NOT NULL,
  `lat` mediumint(8) unsigned NOT NULL,
  `lon` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_group`
--

CREATE TABLE IF NOT EXISTS `people_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `people` mediumint(8) unsigned NOT NULL,
  `group` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_junc`
--

CREATE TABLE IF NOT EXISTS `people_junc` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `f` smallint(5) unsigned NOT NULL,
  `t` smallint(5) unsigned NOT NULL,
  `know` tinyint(3) unsigned NOT NULL,
  `rel` tinyint(3) unsigned NOT NULL,
  `symp` tinyint(3) unsigned NOT NULL,
  `misc` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pgroup`
--

CREATE TABLE IF NOT EXISTS `pgroup` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `desc` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE IF NOT EXISTS `phone` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pid` mediumint(8) unsigned NOT NULL,
  `num` varbinary(10) NOT NULL,
  `desc` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `place`
--

CREATE TABLE IF NOT EXISTS `place` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `lat` mediumint(8) unsigned NOT NULL,
  `lon` mediumint(8) unsigned NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lat` (`lat`),
  KEY `lon` (`lon`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tp` smallint(5) unsigned NOT NULL,
  `desc` varchar(255) NOT NULL,
  `logname` varbinary(32) NOT NULL,
  `rhost` tinyint(3) unsigned NOT NULL,
  `format` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sess`
--

CREATE TABLE IF NOT EXISTS `sess` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` binary(16) NOT NULL,
  `stat` tinyint(3) unsigned NOT NULL,
  `user` smallint(5) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `ua` varbinary(512) NOT NULL,
  `date` datetime NOT NULL,
  `datel` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `stat` (`stat`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ua`
--

CREATE TABLE IF NOT EXISTS `ua` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ua` varbinary(4096) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `spcf` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `cat` tinyint(3) unsigned NOT NULL,
  `login` varbinary(32) NOT NULL,
  `pass` binary(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_cat`
--

CREATE TABLE IF NOT EXISTS `user_cat` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `desc` varchar(256) NOT NULL,
  `perm` varbinary(2048) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE IF NOT EXISTS `visit` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `people` smallint(5) unsigned NOT NULL,
  `place` smallint(5) unsigned NOT NULL,
  `lat` mediumint(8) unsigned NOT NULL,
  `lon` mediumint(8) unsigned NOT NULL,
  `desc` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `water`
--

CREATE TABLE IF NOT EXISTS `water` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `dt` datetime NOT NULL,
  `val` mediumint(8) unsigned NOT NULL,
  `val2` mediumint(8) unsigned NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
